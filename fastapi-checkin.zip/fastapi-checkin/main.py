from fastapi import FastAPI, HTTPException, Form, UploadFile, File
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from psycopg_pool import ConnectionPool   # 不要用 psycopg.pool
from psycopg.rows import dict_row
import redis
import os
from dotenv import load_dotenv
import logging

from fastapi.middleware.cors import CORSMiddleware
load_dotenv()
app = FastAPI(title="CheckIn")

# ===== CORS 允许前端 localhost =====
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],   # 前端 vite 地址
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DSN = os.getenv("DATABASE_URL")
print(DSN)
logging.info(DSN)
# ---------- 连接池（带 dict_row → 行直接变 dict） ----------
pg_pool = ConnectionPool(
    conninfo=DSN,
    min_size=1,
    max_size=20,
    kwargs={"row_factory": dict_row}
)


# ---------- Redis 可选 ----------
try:
    r = redis.from_url(os.getenv("REDIS_URL"), decode_responses=True)
    r.ping()
except Exception:
    r = None

# ---------- 模型 ----------
class CheckInRequest(BaseModel):
    reg_code: str

class CheckInResponse(BaseModel):
    status: str
    seat_number: str | None = None
    table_number: str | None = None

# ---------- 唯一路由 /api/checkin ----------
@app.post("/api/checkin", response_model=CheckInResponse)
def check_in(req: CheckInRequest):
    code = req.reg_code.strip()
    if not code.isdigit() or len(code) != 6:
        raise HTTPException(status_code=400, detail="Invalid reg_code")

    # 1. 缓存
    if r:
        cached = r.hgetall(f"reg:{code}")
        if cached:
            if cached.get("signed") == "1":
                return CheckInResponse(status="already_signed")
            return CheckInResponse(
                status="found",
                seat_number=cached.get("seat"),
                table_number=cached.get("table"),
            )

    # 2. 数据库
    with pg_pool.connection() as conn:          # ✅ psycopg 3 语法
        row = conn.execute(
            "SELECT seat_number, table_number, is_signed FROM attendees WHERE reg_code = %s",
            (code,)
        ).fetchone()

    if row:
        if row["is_signed"] == 1:
            return CheckInResponse(status="already_signed")
        
        # 更新为已签到
        conn.execute(
            "UPDATE attendees SET is_signed = TRUE WHERE reg_code = %s",
            (code,)
        )
        conn.commit()
        
        # 缓存
        if r:
            r.hset(f"reg:{code}", mapping={"seat": row["seat_number"], "table": row["table_number"], "signed": "1"})
            r.expire(f"reg:{code}", 3600)
        
        return CheckInResponse(
            status="found",
            seat_number=row["seat_number"],
            table_number=row["table_number"],
        )

    return CheckInResponse(status="not_found")

# ---------- 管理员页面 ----------
@app.get("/admin", response_class=HTMLResponse)
def admin_page(password: str = ""):
    if password != "admin123":  # 简单密码验证
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    
    # 简单的 HTML 页面
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Admin Panel</title>
        <style>
            body { font-family: Arial; margin: 20px; }
            form { margin-bottom: 20px; }
            input { margin: 5px; }
        </style>
    </head>
    <body>
        <h1>管理员面板</h1>
        
        <h2>查询用户</h2>
        <form action="/admin/query" method="post">
            <input type="hidden" name="password" value="admin123">
            <input type="text" name="reg_code" placeholder="注册码" required>
            <button type="submit">查询</button>
        </form>
        
        <form action="/admin/query_all" method="post">
            <input type="hidden" name="password" value="admin123">
            <button type="submit">查询全部</button>
        </form>
        
        <h2>添加用户</h2>
        <form action="/admin/add" method="post">
            <input type="hidden" name="password" value="admin123">
            <input type="text" name="reg_code" placeholder="注册码" required>
            <input type="text" name="seat_number" placeholder="座位号" required>
            <input type="text" name="table_number" placeholder="桌号" required>
            <button type="submit">添加</button>
        </form>
        
        <h2>修改用户</h2>
        <form action="/admin/update" method="post">
            <input type="hidden" name="password" value="admin123">
            <input type="text" name="reg_code" placeholder="注册码" required>
            <input type="text" name="seat_number" placeholder="新座位号">
            <input type="text" name="table_number" placeholder="新桌号">
            <input type="number" name="is_signed" placeholder="已签到(0/1)">
            <button type="submit">修改</button>
        </form>
        
        <h2>删除用户</h2>
        <form action="/admin/delete" method="post">
            <input type="hidden" name="password" value="admin123">
            <input type="text" name="reg_code" placeholder="注册码" required>
            <button type="submit">删除</button>
        </form>
        
        <h2>批量上传 CSV</h2>
        <form action="/admin/upload_csv" method="post" enctype="multipart/form-data">
            <input type="hidden" name="password" value="admin123">
            <input type="file" name="file" accept=".csv" required>
            <button type="submit">上传</button>
        </form>
        <p>CSV 格式：reg_code,seat_number,table_number（第一行标题）</p>
    </body>
    </html>
    """
    return HTMLResponse(html)

# ---------- 管理员操作 ----------
from fastapi import UploadFile, File
import csv
import io

@app.post("/admin/query_all", response_class=HTMLResponse)
def admin_query_all(password: str = Form(...)):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    
    with pg_pool.connection() as conn:
        rows = conn.execute("SELECT * FROM attendees").fetchall()
    
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>All Users</title>
        <style>
            body { font-family: Arial; margin: 20px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
        </style>
    </head>
    <body>
        <h1>所有用户</h1>
        <a href="/admin?password=admin123">返回管理员面板</a>
        <br><br>
        <table>
            <tr><th>注册码</th><th>座位号</th><th>桌号</th><th>已签到</th><th>是否已中奖</th></tr>
    """
    for row in rows:
        won = '是' if row.get('result') and row['result'].strip() else '否'
        html += """
            <tr>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
            </tr>
        """.format(row["reg_code"], row["seat_number"], row["table_number"], row["is_signed"], won)
    
    html += "</table></body></html>"
    return HTMLResponse(html)

@app.post("/admin/query", response_class=HTMLResponse)
def admin_query(password: str = Form(...), reg_code: str = Form(...)):
    if password != "admin123":
        return HTMLResponse("<h1>Access Denied</h1>", status_code=403)
    
    with pg_pool.connection() as conn:
        row = conn.execute(
            "SELECT * FROM attendees WHERE reg_code = %s",
            (reg_code,)
        ).fetchone()
    
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Query Result</title>
        <style>
            body { font-family: Arial; margin: 20px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
        </style>
    </head>
    <body>
        <h1>查询结果</h1>
        <a href="/admin?password=admin123">返回管理员面板</a>
        <br><br>
    """
    if row:
        html += """
        <table>
            <tr><th>注册码</th><th>座位号</th><th>桌号</th><th>已签到</th><th>是否已中奖</th></tr>
            <tr>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
                <td>{}</td>
            </tr>
        </table>
        """.format(row["reg_code"], row["seat_number"], row["table_number"], row["is_signed"], '是' if row.get('result') and row['result'].strip() else '否')
    else:
        html += "<p>未找到用户</p>"
    
    html += "</body></html>"
    return HTMLResponse(html)

@app.post("/admin/add")
def admin_add(password: str = Form(...), reg_code: str = Form(...), seat_number: str = Form(...), table_number: str = Form(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    
    with pg_pool.connection() as conn:
        conn.execute(
            "INSERT INTO attendees (reg_code, seat_number, table_number, is_signed) VALUES (%s, %s, %s, FALSE)",
            (reg_code, seat_number, table_number)
        )
        conn.commit()
    
    return {"message": "Added"}

@app.post("/admin/update")
def admin_update(password: str = Form(...), reg_code: str = Form(...), seat_number: str = Form(""), table_number: str = Form(""), is_signed: int = Form(None)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    
    updates = []
    params = []
    if seat_number:
        updates.append("seat_number = %s")
        params.append(seat_number)
    if table_number:
        updates.append("table_number = %s")
        params.append(table_number)
    if is_signed is not None:
        updates.append("is_signed = %s")
        params.append(is_signed)
    
    if not updates:
        return {"message": "No updates"}
    
    params.append(reg_code)
    
    with pg_pool.connection() as conn:
        conn.execute(
            f"UPDATE attendees SET {', '.join(updates)} WHERE reg_code = %s",
            params
        )
        conn.commit()
    
    return {"message": "Updated"}

@app.post("/admin/delete")
def admin_delete(password: str = Form(...), reg_code: str = Form(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    
    with pg_pool.connection() as conn:
        conn.execute(
            "DELETE FROM attendees WHERE reg_code = %s",
            (reg_code,)
        )
        conn.commit()
    
    return {"message": "Deleted"}

@app.post("/admin/upload_csv")
def admin_upload_csv(password: str = Form(...), file: UploadFile = File(...)):
    if password != "admin123":
        raise HTTPException(status_code=403, detail="Access Denied")
    
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files allowed")
    
    content = file.file.read().decode('utf-8-sig')
    reader = csv.DictReader(io.StringIO(content))
    
    inserted = 0
    updated = 0
    errors = []
    
    with pg_pool.connection() as conn:
        for row in reader:
            reg_code = row.get('reg_code', '').strip()
            if not reg_code:
                continue
            
            # Prepare data
            data = {}
            for key, value in row.items():
                if key == 'reg_code':
                    continue
                if key == 'is_signed':
                    data[key] = value.strip().lower() in ('true', '1', 'yes')
                else:
                    data[key] = value.strip() if value else None
            
            try:
                # Check if exists
                existing = conn.execute(
                    "SELECT 1 FROM attendees WHERE reg_code = %s",
                    (reg_code,)
                ).fetchone()
                
                if existing:
                    # Update
                    if data:
                        set_parts = [f"{k} = %s" for k in data.keys()]
                        values = list(data.values()) + [reg_code]
                        conn.execute(
                            f"UPDATE attendees SET {', '.join(set_parts)} WHERE reg_code = %s",
                            values
                        )
                    updated += 1
                else:
                    # Insert
                    columns = ['reg_code'] + list(data.keys())
                    placeholders = ', '.join(['%s'] * len(columns))
                    values = [reg_code] + list(data.values())
                    conn.execute(
                        f"INSERT INTO attendees ({', '.join(columns)}) VALUES ({placeholders})",
                        values
                    )
                    inserted += 1
            except Exception as e:
                errors.append(f"Error with {reg_code}: {str(e)}")
        conn.commit()
    
    message = f"Processed: {inserted} inserted, {updated} updated"
    if errors:
        message += f" Errors: {errors}"
    
    return {"message": message}

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
