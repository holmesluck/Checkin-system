import vue from '@vitejs/plugin-vue'

export default {
	plugins: [vue()],
	server: {
		port: 3001,
		open: true,
		host: '0.0.0.0'   // ← 新增这一行
	}
}
