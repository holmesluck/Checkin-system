/* ===== 只用改这两行 ===== */
const USE_MOCK = false                           // true=假数据，false=真接口
const baseURL = 'http://localhost:8000'        // 后端地址

export async function checkIn(reg_code) {
	// 1. 本地 mock
	if (USE_MOCK) {
		const mockDB = {
			123456: { seat: 'A12', table: 'T5' },
			654321: { seat: 'B08', table: 'T2' }
		}
		const row = mockDB[reg_code]
		return row
			? { status: 'found', seat_number: row.seat, table_number: row.table }
			: { status: 'not_found', seat_number: null, table_number: null }
	}

	// 2. 真实后端
	try {
		console.log('Sending POST request to:', `${baseURL}/api/checkin`, 'with body:', { reg_code })
		const res = await fetch(`${baseURL}/api/checkin`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ reg_code })
		})
		if (!res.ok) {
			throw new Error(`HTTP error! status: ${res.status}`)
		}
		return await res.json()
	} catch (error) {
		console.error('Check-in request failed:', error)
		return { status: 'error', message: error.message }
	}
}
