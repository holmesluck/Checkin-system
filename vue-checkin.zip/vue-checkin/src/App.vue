<template>
  <!-- 唯一根元素 -->
  <div>
    <!-- 1. 像素背景层 -->
    <section class="mc-bg">
      <div class="horse-line"></div>
    </section>

    <!-- 2. 原表单 -->
    <section class="box">
      <h2>2026 Conference Check-in</h2>
      <input
        v-model="code"
        type="text"
        pattern="\d{6}"
        maxlength="6"
        placeholder="Enter 6-digit code"
      />
      <button @click="handleCheck">Check</button>

      <div v-if="result" class="result">
        <p v-if="result.status==='found'">
          Seat: {{ result.seat_number }} &nbsp; Table: {{ result.table_number }}
        </p>
        <p v-else-if="result.status==='already_signed'">
          Code already checked-in
        </p>
        <p v-else-if="result.status==='error'">
          Failed: {{ result.message }}
        </p>
        <p v-else>No info found</p>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { checkIn } from './api/checkin'
const code = ref('')
const result = ref(null)
async function handleCheck() {
  console.log('Button clicked, code:', code.value, 'length:', code.value.length)
  if (code.value.length !== 6) {
    result.value = { status: 'error', message: '输入的代码未找到，请重新检查您的注册代码，请输入 6 有效位数字'}
    return
  }
  console.log('Calling checkIn with:', code.value)
  result.value = await checkIn(code.value)
}
</script>

<style scoped>
/*======== 1. 像素字体 =========*/
* {
  font-family: "Courier New", SimSun, monospace;
  image-rendering: pixelated;          /* 让浏览器强行把图形边缘锐化 */
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
}

/*======== 2. 背景层：草方块 =========*/
.mc-bg {
  position: fixed;
  inset: 0;
  z-index: 1;
  background: 
    /* 16×16 草方块纹理 */
    0 0 / 32px 32px
    repeating-conic-gradient(
        #6c9b2f 0% 25%,
        #5a8228 0% 50%
    );
  /* 给方块加一条“草边” */
  box-shadow: inset 0 0 0 1px #4a6c20;
}

/*======== 3. 飘动像素马 =========*/
/*======== 背景层 ========*/
.mc-bg {
  position: fixed;
  inset: 0;
  overflow: hidden;
  background: 0 0 / 32px 32px
              repeating-conic-gradient(#6c9b2f 0% 25%, #5a8228 0% 50%);
  box-shadow: inset 0 0 0 1px #4a6c20;
  z-index: 1;
}

/*======== 马队列 ========*/
.horse-line {
  position: absolute;
  bottom: 20%;                 /* 纵向位置可改 */
  display: flex;
  width: 200vw;                /* 两倍屏宽，保证循环不中断 */
  animation: march 8s linear infinite;
}

.horse-line::before,
.horse-line::after {
  content: '';
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-around;
  font-size: 3rem;             /* 图标大小 */
  color: #8B4513;
}

/* 每段放 20 匹马 */
.horse-line::before { content: '🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎'; }
.horse-line::after  { content: '🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎🐎'; }

/*======== 整体平移 ========*/
@keyframes march {
  to { transform: translateX(-100vw); }
}



/*======== 4. 工作台表单 =========*/
.box {
  position: relative;
  z-index: 10;
  max-width: 320px;
  margin: 60px auto;
  text-align: center;
  background: #8b4513;
  border: 6px solid #5d2c0f;
  box-shadow: 0 0 0 2px #3e1e0a, 0 0 20px rgba(0, 0, 0, .6);
  padding: 20px;              /* 原来 30px 20px → 20px */
}

input {
  width: 100%;
  padding: 8px 12px;
  margin-bottom: 12px;
  font-size: 16px;
  border: 2px solid #5d2c0f;
  background: #fde5a4;
  color: #3e1e0a;
  outline: none;
  box-sizing: border-box;    /* 关键：把 border 和 padding 算进宽度 */
}

h2 {
  margin: 0 0 20px;
  color: #fde5a4;                 /* 金胡萝卜色 */
  text-shadow: 2px 2px 0 #5d2c0f;
  letter-spacing: 1px;
}

button {
  width: 100%;
  padding: 8px 0;
  font-size: 16px;
  background: #6b8e23;            /* 苔石按钮 */
  color: #fff;
  border: 2px solid #5d2c0f;
  cursor: pointer;
}
button:hover { background: #556b2f; }
button:active { transform: translateY(2px); }

.result {
  margin-top: 15px;
  color: #fde5a4;
  font-weight: bold;
  text-shadow: 1px 1px 0 #5d2c0f;
}
</style>

